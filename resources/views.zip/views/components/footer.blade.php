
<section id="footer">
    <footer>
        <div class="footer">
            <div class="container">
                <div class="row footer-content">
                    <div class="col-md-5 colf">
                        <h5 class="foot-title"> IRN NEPAL </h5>
                        <p class="foot-para">Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                            Quae nihil, dolorum quasi, ipsa, id sapiente voluptatibus
                            maxime veniam laboriosam nobis.</p>
                    </div>
                    <div class="col-md-3 colf">
                        <h5 class="foot-title">Quick Links</h5>
                        <li><a href="{{ env('APP_URL') }}">Home</a></li>
                        <li><a href="{{ env('APP_URL') }}/about">About Us</a></li>
                        <li><a href="{{ env('APP_URL') }}/gallery">Gallery</a></li>
                    </div>
                    <div class="col-md-4 colf">
                        <h5 class="foot-title">Contact Address</h5>
                        <li>Tyangla Phaat, Kirtipur Nepal</li>
                        <li>+977 984568215, +977 01562458</li>
                        <li><a href="email:email@gmail.com">info@gmail.com</a></li>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</section>