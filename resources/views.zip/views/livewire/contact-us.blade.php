<section>

    <section id="bredcrumb">
        <div class="bredcrumb-content">
            <h1 class="text-white text-center pt-4">Contact Us</h1>
        </div>
        <div class="container">
            <ul class="breadcrumb mt-3">
                <li><a href="{% url 'home' %}">Home</a></li>
                <li><a href="#" class="active">Contact Us</a></li>
            </ul>
        </div>
        <hr>
    </section>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mb-3">
                <div>
                    @if (session()->has('page-message'))
                        <div class="alert alert-success rounded-0 alert-dismissible fade show mt-3" role="alert">
                            {{ session('page-message') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    @endif
                </div>

                <h2 class="custom-fs-36 custom-text-black custom-fw-700 my-3"> Leave
                    message Here:</h2>
                <form wire:submit.prevent="save" class="row">
                    <div class="form-wrap col-md-6">
                        <input wire:mode="name" type="text"
                            class="form-control mb-3 p-3 rounded-0 @error('name') border-danger @enderror" required
                            placeholder="Name">
                    </div>
                    <div class="form-wrap col-md-6">
                        <input wire:model="email" type="email"
                            class="form-control mb-3 p-3 rounded-0 @error('email') border-danger @enderror"
                            placeholder="Email Address">
                    </div>
                    <div class="form-wrap col-md-12">
                        <input wire:model="subject" type="text"
                            class="form-control mb-3 p-3 rounded-0 @error('subject') border-danger @enderror"
                            placeholder="Subject">
                    </div>
                    <div class="form-wrap col-md-12">
                        <div class="form-floating">
                            <textarea wire:model="comment"
                                class="form-control mb-3 p-3  rounded-0 @error('comment') border-danger @enderror"
                                placeholder="Leave a comment here..." style="height: 120px"></textarea>
                        </div>
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary submit-btn">Submit</button>
                    </div>
                </form>
            </div>
            <div class="col-lg-6">
                @include('components.notice')
            </div>
        </div>

</section>
